package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentAddressService {
	@Autowired
	StudentAddressRepository studentAddressRepository;
	
	 public List<StudentAddress> getAllStudents()
	    {
	        List<StudentAddress> employeeList = studentAddressRepository.findAll();
	         
	        if(employeeList.size() > 0) {
	            return employeeList;
	        } else {
	            return new ArrayList<StudentAddress>();
	        }
	    }
	
	public StudentAddress createOrUpdateStudnet(StudentAddress studentAddress) throws Exception
    {
        Optional<StudentAddress> student1 = studentAddressRepository.findById(studentAddress.getId());
        
         
        if(student1.isPresent())
        	
        {
        
           StudentAddress newStudentAddress = student1.get();
           newStudentAddress.setId(studentAddress.getId());
           newStudentAddress.setStreet(studentAddress.getState());
           newStudentAddress.setCity(studentAddress.getCity());
           newStudentAddress.setState(studentAddress.getState());
           newStudentAddress.setZipcode(studentAddress.getZipcode());
        
    
 
           newStudentAddress = studentAddressRepository.save(newStudentAddress);
             
            return newStudentAddress;
        } else {
            studentAddress = studentAddressRepository.save(studentAddress);
             
            return studentAddress;
        }
    }
	
	 public StudentAddress getStudentsEmail(int id) throws Exception 
	    {
	        Optional<StudentAddress> employee = studentAddressRepository.findById(id);
	         
	        if(employee.isPresent()) {
	            return employee.get();
	        } else {
	            throw new Exception("No employee record exist for given id");
	        }
	    }

}
