package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="studentaddress")
public class StudentAddress {
	  @Id
	  //@GeneratedValue(strategy=GenerationType.AUTO) 
	 @Column(name = " id")
	private int id;
    @Column(name = "street")
	private String street;
    @Column(name = "city")
	private String city;
    @Column(name = "state")
	private String state;
    @Column(name = "zipcode")
	private String zipcode;
    @OneToOne(targetEntity=Student.class)  
    private Student student;
    
	public Student getStudent() {
		return student;
	}


	public void setStudent(Student student) {
		this.student = student;
	}


	public StudentAddress( String Street,String city,String state,String zipcode) {
		this.street=Street;
		this.city=city;
		this.state=state;
		this.zipcode=zipcode;
	
		
	}


	


	public StudentAddress() {
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
}