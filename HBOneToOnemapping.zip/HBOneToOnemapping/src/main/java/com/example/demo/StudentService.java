package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentService {
	
	  @Autowired
	  StudentRepository repository;

	  
	  public List<Student> getAllStudents()
	    {
	        List<Student> employeeList = repository.findAll();
	         
	        if(employeeList.size() > 0) {
	            return employeeList;
	        } else {
	            return new ArrayList<Student>();
	        }
	    }
	  
	  public Student getStudentsEmail(int id) throws Exception 
	    {
	        Optional<Student> employee = repository.findById(id);
	         
	        if(employee.isPresent()) {
	            return employee.get();
	        } else {
	            throw new Exception("No employee record exist for given id");
	        }
	    }
	  
	    public Student createOrUpdateStudnet(Student student) throws Exception
	    {
	    	StudentAddress sAddress =new StudentAddress();
	        Optional<Student> student1 = repository.findById(student.getId());
	        
	         
	        if(student1.isPresent())
	        	
	        {
	        
	           Student newStudent = student1.get();
	           newStudent.setId(student.getId());
	           newStudent.setFirstname(student.getFirstname());
	           newStudent.setLastname(student.getLastname());
	           newStudent.setEmail(student.getEmail());
	           newStudent.setUsername(student.getUsername());
	           newStudent.setPassword(student.getPassword());
	           newStudent.setConfirmpassword(student.getConfirmpassword());
	           
	           StudentAddress address1= new StudentAddress();
	           address1.setId(sAddress.getId());
	           
	           address1.setStreet(sAddress.getStreet());
	           address1.setCity(sAddress.getCity());
	           address1.setState(sAddress.getState());
	           address1.setZipcode(sAddress.getZipcode());
	           
	           newStudent.setStudentaddress(address1);
	          
	 
	           newStudent = repository.save(newStudent);
	             
	            return newStudent;
	        } else {
	        	
	        	StudentAddress address=new StudentAddress();
	         	address.setId(address.getId());
	        	address.setStreet(address.getStreet());
	          	address.setCity(address.getCity());
	          	address.setState(address.getState());
	          	address.setZipcode(address.getZipcode());
	          	
	            student.setId(student.getId());
	            student.setFirstname(student.getFirstname());
	            student.setLastname(student.getLastname());
	            student.setEmail(student.getEmail());
	            student.setUsername(student.getUsername());
	            student.setPassword(student.getPassword());
	            student.setConfirmpassword(student.getConfirmpassword());
	        	
	            student = repository.save(student);
	             
	            return student;
	        }
	    }
	    @Transactional
	    public void deleteStudentById(int id) throws Exception
	    {
	        Optional<Student> employee = repository.findById(id);
	         
	        if(employee.isPresent())
	        {
	            repository.deleteById(id);
	        } else {
	            throw new Exception("No employee record exist for given id");
	        }
	    }
}
